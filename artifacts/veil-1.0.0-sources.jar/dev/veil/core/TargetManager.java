package dev.veil.core;

import dev.veil.modules.combat.AntiBot;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Single place that answers "who am I looking at". Keeping selection here means aim assist,
 * trigger bot and the target hud can never disagree about the current target.
 */
public final class TargetManager {
    public enum Sort {
        ANGLE, DISTANCE, HEALTH
    }

    private static final class_310 MC = class_310.method_1551();
    private static class_1309 current;

    private TargetManager() {
    }

    public static class_1309 current() {
        return current;
    }

    public static void update() {
        current = find(6.0, 180.0, false, false, Sort.ANGLE);
    }

    public static class_1309 find(double range, double fov, boolean includeMobs, boolean requireVisible, Sort sort) {
        class_746 player = MC.field_1724;
        if (player == null || MC.field_1687 == null) {
            return null;
        }

        double rangeSq = range * range;
        class_238 search = player.method_5829().method_1014(range);
        List<class_1309> candidates = new ArrayList<>();

        for (class_1297 entity : MC.field_1687.method_8333(player, search, e -> e instanceof class_1309 && e.method_5805())) {
            if (!(entity instanceof class_1309 living) || living == player) {
                continue;
            }
            if (!(living instanceof class_1657) && !includeMobs) {
                continue;
            }
            if (living.method_6032() <= 0.0f || living.method_31481()) {
                continue;
            }
            if (player.method_5858(living) > rangeSq) {
                continue;
            }
            if (!AntiBot.accepts(living)) {
                continue;
            }
            if (requireVisible && !player.method_6057(living)) {
                continue;
            }
            double angle = Rotation.angleTo(player.method_33571(), living.method_5829().method_1005(), player.method_36454(), player.method_36455());
            if (angle > fov * 0.5) {
                continue;
            }
            candidates.add(living);
        }

        if (candidates.isEmpty()) {
            return null;
        }

        class_243 eye = player.method_33571();
        Comparator<class_1309> comparator = switch (sort) {
            case DISTANCE -> Comparator.comparingDouble(player::method_5858);
            case HEALTH -> Comparator.comparingDouble(class_1309::method_6032);
            case ANGLE -> Comparator.comparingDouble(e ->
                    Rotation.angleTo(eye, e.method_5829().method_1005(), player.method_36454(), player.method_36455()));
        };

        candidates.sort(comparator);
        return candidates.get(0);
    }

    /** Best point on the hitbox to aim at, nudged to the closest visible corner for a natural path. */
    public static class_243 aimPoint(class_1309 target, boolean head) {
        class_238 box = target.method_5829();
        if (head && target instanceof class_1657) {
            return new class_243(box.method_1005().field_1352, box.field_1325 - 0.12, box.method_1005().field_1350);
        }
        return new class_243(box.method_1005().field_1352, box.field_1322 + box.method_17940() * 0.62, box.method_1005().field_1350);
    }
}
