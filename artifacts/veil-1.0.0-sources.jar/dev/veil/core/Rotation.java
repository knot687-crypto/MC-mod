package dev.veil.core;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * Rotation math shared by every aim feature. Deltas are snapped to the mouse sensitivity
 * grid the same way real mouse input is, which keeps synthetic movement inside the
 * distribution a human hand produces.
 */
public final class Rotation {
    private static final class_310 MC = class_310.method_1551();

    private Rotation() {
    }

    public static Angle look(class_243 from, class_243 to, boolean vertical) {
        double dx = to.field_1352 - from.field_1352;
        double dy = to.field_1351 - from.field_1351;
        double dz = to.field_1350 - from.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));
        return new Angle(yaw, vertical ? pitch : MC.field_1724 == null ? pitch : MC.field_1724.method_36455());
    }

    /** Applies one smoothing step toward the target on the player camera. */
    public static void apply(Angle target, double speed, double randomization, boolean vertical) {
        class_746 player = MC.field_1724;
        if (player == null) {
            return;
        }
        double clamp = Math.max(0.01, Math.min(1.0, speed / 10.0));
        float curve = (float) (clamp * 0.72 + 0.04);
        float yawDelta = class_3532.method_15393(target.yaw() - player.method_36454());
        float pitchDelta = class_3532.method_15393(target.pitch() - player.method_36455());

        if (randomization > 0.0) {
            double noise = ThreadLocalRandom.current().nextDouble(-1.0, 1.0) * randomization * 0.12;
            curve = (float) Math.max(0.01, Math.min(1.0, curve + noise));
        }

        float yawStep = quantize(yawDelta * curve);
        player.method_36456(player.method_36454() + yawStep);

        if (vertical) {
            float pitchStep = quantize(pitchDelta * curve);
            player.method_36457(class_3532.method_15363(player.method_36455() + pitchStep, -90.0f, 90.0f));
        }
    }

    public static float yawTo(class_243 from, class_243 to) {
        double dx = to.field_1352 - from.field_1352;
        double dz = to.field_1350 - from.field_1350;
        return (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
    }

    public static float pitchTo(class_243 from, class_243 to) {
        double dx = to.field_1352 - from.field_1352;
        double dy = to.field_1351 - from.field_1351;
        double dz = to.field_1350 - from.field_1350;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, horizontal));
    }

    /** Angular distance in degrees between where the player looks and a point in the world. */
    public static double angleTo(class_243 from, class_243 to, float yaw, float pitch) {
        float targetYaw = yawTo(from, to);
        float targetPitch = pitchTo(from, to);
        double yawDelta = class_3532.method_15393(targetYaw - yaw);
        double pitchDelta = targetPitch - pitch;
        return Math.sqrt(yawDelta * yawDelta + pitchDelta * pitchDelta);
    }

    /**
     * Minecraft's mouse pipeline multiplies raw input by a sensitivity derived step. Snapping
     * to that step removes the floating point tell of direct camera writes.
     */
    private static float quantize(float delta) {
        double sensitivity = MC.field_1690.method_42495().method_41753();
        double f = sensitivity * 0.6 + 0.2;
        double gcd = f * f * f * 8.0 * 0.15;
        if (gcd <= 1.0E-7) {
            return delta;
        }
        return (float) (Math.round(delta / gcd) * gcd);
    }

    public record Angle(float yaw, float pitch) {
    }
}
