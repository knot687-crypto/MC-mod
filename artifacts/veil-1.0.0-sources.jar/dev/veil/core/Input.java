package dev.veil.core;

import dev.veil.mixin.MinecraftClientAccessor;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_310;

public final class Input {
    private static final class_310 MC = class_310.method_1551();

    private Input() {
    }

    /** Runs vanilla's own attack path so cooldowns, blocking and swing packets stay intact. */
    public static void leftClick() {
        // Entity hits are counted by the interaction mixin; only count the rest here.
        if (!(MC.field_1765 instanceof net.minecraft.class_3966)) {
            CombatStats.onClick();
        }
        ((MinecraftClientAccessor) MC).veil$doAttack();
    }

    public static void attack(class_1297 target) {
        if (MC.field_1724 == null || MC.field_1761 == null) {
            return;
        }
        MC.field_1761.method_2918(MC.field_1724, target);
        MC.field_1724.method_6104(class_1268.field_5808);
    }

    public static void swing() {
        if (MC.field_1724 != null) {
            MC.field_1724.method_6104(class_1268.field_5808);
        }
    }
}
