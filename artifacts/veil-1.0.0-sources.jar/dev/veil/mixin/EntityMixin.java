package dev.veil.mixin;

import dev.veil.modules.combat.HitBox;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public abstract class EntityMixin {
    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
    private void veil$expandHitbox(CallbackInfoReturnable<class_238> info) {
        class_1297 self = (class_1297) (Object) this;
        if (!HitBox.shouldExpand(self)) {
            return;
        }
        info.setReturnValue(info.getReturnValue().method_1014(HitBox.expansion()));
    }
}
