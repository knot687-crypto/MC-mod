package dev.veil.mixin;

import dev.veil.modules.combat.Velocity;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"))
    private void veil$onVelocity(class_2743 packet, CallbackInfo info) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && packet.method_11818() == mc.field_1724.method_5628()) {
            Velocity.onKnockback();
        }
    }
}
