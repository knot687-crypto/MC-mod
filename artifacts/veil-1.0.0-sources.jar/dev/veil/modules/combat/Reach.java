package dev.veil.modules.combat;

import dev.veil.core.Category;
import dev.veil.core.Module;
import dev.veil.core.NumberSetting;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_746;

public final class Reach extends Module {
    private static final class_310 MC = class_310.method_1551();
    private static final class_2960 ENTITY_ID = class_2960.method_60655("veil", "reach_entity");
    private static final class_2960 BLOCK_ID = class_2960.method_60655("veil", "reach_block");
    private static final double VANILLA_RANGE = 3.0;

    private final NumberSetting entityRange = add(new NumberSetting("Entity", "Entity interaction range.", 3.4, 3.0, 6.0, 0.1, ""));
    private final NumberSetting blockRange = add(new NumberSetting("Block", "Block interaction range.", 4.8, 4.5, 7.0, 0.1, ""));

    private double appliedEntity = -1.0;
    private double appliedBlock = -1.0;

    public Reach() {
        super("Reach", "Extends the client interaction range through vanilla attributes.", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        appliedEntity = -1.0;
        appliedBlock = -1.0;
    }

    @Override
    public void onDisable() {
        class_746 player = MC.field_1724;
        if (player == null) {
            return;
        }
        clear(player.method_5996(class_5134.field_47759), ENTITY_ID);
        clear(player.method_5996(class_5134.field_47758), BLOCK_ID);
        appliedEntity = -1.0;
        appliedBlock = -1.0;
    }

    @Override
    public void onTick() {
        class_746 player = MC.field_1724;
        if (player == null) {
            return;
        }
        if (entityRange.value() != appliedEntity) {
            apply(player.method_5996(class_5134.field_47759), ENTITY_ID, entityRange.value());
            appliedEntity = entityRange.value();
        }
        if (blockRange.value() != appliedBlock) {
            apply(player.method_5996(class_5134.field_47758), BLOCK_ID, blockRange.value());
            appliedBlock = blockRange.value();
        }
    }

    private static void apply(class_1324 instance, class_2960 id, double target) {
        if (instance == null) {
            return;
        }
        instance.method_6200(id);
        instance.method_26837(new class_1322(id, target - VANILLA_RANGE, class_1322.class_1323.field_6328));
    }

    private static void clear(class_1324 instance, class_2960 id) {
        if (instance != null) {
            instance.method_6200(id);
        }
    }

    public double entityRange() {
        return entityRange.value();
    }
}
