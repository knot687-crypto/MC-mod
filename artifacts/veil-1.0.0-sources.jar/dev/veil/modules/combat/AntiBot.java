package dev.veil.modules.combat;

import dev.veil.Veil;
import dev.veil.core.BoolSetting;
import dev.veil.core.Category;
import dev.veil.core.Module;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_640;

/**
 * Drops synthetic entities that servers spawn to bait aim and trigger features.
 */
public final class AntiBot extends Module {
    private final BoolSetting uuid = add(new BoolSetting("UUID", "Reject entities with non v4 UUIDs.", true));
    private final BoolSetting tab = add(new BoolSetting("Tab", "Reject players missing from the tab list.", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", "Reject entries with a zero read latency.", false));

    public AntiBot() {
        super("Anti Bot", "Filters server side decoys out of every target list.", Category.COMBAT);
    }

    public static boolean accepts(class_1309 entity) {
        AntiBot module = Veil.modules().get(AntiBot.class);
        if (module == null || !module.isEnabled()) {
            return true;
        }
        if (!(entity instanceof class_1657 player)) {
            return true;
        }
        if (module.uuid.value() && player.method_5667().version() != 4) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        if (mc.method_1562() == null) {
            return true;
        }
        class_640 entry = mc.method_1562().method_2871(player.method_5667());
        if (module.tab.value() && entry == null) {
            return false;
        }
        if (module.ping.value() && entry != null && entry.method_2959() <= 0) {
            return false;
        }
        return true;
    }
}
