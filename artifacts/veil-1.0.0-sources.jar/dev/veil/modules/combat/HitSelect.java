package dev.veil.modules.combat;

import dev.veil.core.Category;
import dev.veil.core.Module;
import dev.veil.core.ModeSetting;
import dev.veil.core.NumberSetting;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class HitSelect extends Module {
    private static final class_310 MC = class_310.method_1551();

    private final ModeSetting mode = add(new ModeSetting("Mode", "Sprint behaviour after a hit lands.", "W Tap", "W Tap", "Sprint Reset", "Keep Sprint"));
    private final NumberSetting delay = add(new NumberSetting("Delay", "Time the sprint stays released.", 60.0, 10.0, 250.0, 5.0, "ms"));

    private long releaseUntil;

    public HitSelect() {
        super("Hit Select", "Resets sprint on hit to shed knockback and keep combos tight.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        class_746 player = MC.field_1724;
        if (player == null) {
            return;
        }
        if (releaseUntil != 0L && System.currentTimeMillis() >= releaseUntil) {
            releaseUntil = 0L;
            MC.field_1690.field_1867.method_23481(true);
        }
    }

    /** Fired from the attack mixin so manual and automated clicks behave identically. */
    public void onAttack(boolean sprinting) {
        if (!isEnabled() || MC.field_1724 == null) {
            return;
        }
        if (mode.value().equals("Keep Sprint")) {
            MC.field_1690.field_1867.method_23481(true);
            MC.field_1724.method_5728(true);
            return;
        }
        if (mode.value().equals("Sprint Reset") && !MC.field_1690.field_1867.method_1434()) {
            return;
        }
        MC.field_1690.field_1867.method_23481(false);
        MC.field_1724.method_5728(false);
        releaseUntil = System.currentTimeMillis() + Math.round(delay.value());
    }

    @Override
    protected void onDisable() {
        releaseUntil = 0L;
    }
}
