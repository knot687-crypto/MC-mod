package dev.veil.modules.combat;

import dev.veil.Veil;
import dev.veil.core.Category;
import dev.veil.core.Module;
import dev.veil.core.NumberSetting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_243;

public final class Velocity extends Module {
    private final NumberSetting horizontal = add(new NumberSetting("Horizontal", "Horizontal knockback kept.", 0.0, 0.0, 100.0, 1.0, "%"));
    private final NumberSetting vertical = add(new NumberSetting("Vertical", "Vertical knockback kept.", 0.0, 0.0, 100.0, 1.0, "%"));
    private final NumberSetting chance = add(new NumberSetting("Chance", "Chance for the reduction to apply.", 100.0, 0.0, 100.0, 1.0, "%"));

    public Velocity() {
        super("Velocity", "Trims incoming knockback before it reaches the camera.", Category.COMBAT);
    }

    /** Called from the network mixin right after vanilla applies the packet. */
    public static void onKnockback() {
        Velocity module = Veil.modules().get(Velocity.class);
        if (module == null || !module.isEnabled() || net.minecraft.class_310.method_1551().field_1724 == null) {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble(100.0) > module.chance.value()) {
            return;
        }
        class_243 velocity = net.minecraft.class_310.method_1551().field_1724.method_18798();
        net.minecraft.class_310.method_1551().field_1724.method_18800(
                velocity.field_1352 * (module.horizontal.value() / 100.0),
                velocity.field_1351 * (module.vertical.value() / 100.0),
                velocity.field_1350 * (module.horizontal.value() / 100.0));
    }
}
