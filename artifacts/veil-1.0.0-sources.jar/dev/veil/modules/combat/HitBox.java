package dev.veil.modules.combat;

import dev.veil.Veil;
import dev.veil.core.BoolSetting;
import dev.veil.core.Category;
import dev.veil.core.Module;
import dev.veil.core.NumberSetting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public final class HitBox extends Module {
    private final NumberSetting scale = add(new NumberSetting("Scale", "Hitbox multiplier for other entities.", 1.25, 1.0, 2.0, 0.05, "x"));
    private final BoolSetting players = add(new BoolSetting("Players Only", "Leave mobs untouched.", true));

    public HitBox() {
        super("Hit Box", "Expands target boxes client side for easier tracking.", Category.COMBAT);
    }

    public static boolean shouldExpand(class_1297 entity) {
        HitBox module = Veil.modules().get(HitBox.class);
        if (module == null || !module.isEnabled()) {
            return false;
        }
        if (!(entity instanceof class_1309)) {
            return false;
        }
        if (module.players.value() && !(entity instanceof class_1657)) {
            return false;
        }
        return entity != net.minecraft.class_310.method_1551().field_1724;
    }

    public static double expansion() {
        HitBox module = Veil.modules().get(HitBox.class);
        if (module == null) {
            return 0.0;
        }
        return (module.scale.value() - 1.0) * 0.5;
    }
}
