package dev.veil.modules.combat;

import dev.veil.core.BoolSetting;
import dev.veil.core.Category;
import dev.veil.core.Input;
import dev.veil.core.Module;
import dev.veil.core.NumberSetting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;

public final class TriggerBot extends Module {
    private static final class_310 MC = class_310.method_1551();

    private final NumberSetting range = add(new NumberSetting("Range", "Maximum trigger distance.", 3.2, 1.0, 6.0, 0.1, ""));
    private final NumberSetting delay = add(new NumberSetting("Delay", "Reaction time before the hit fires.", 55.0, 0.0, 300.0, 5.0, "ms"));
    private final BoolSetting weapon = add(new BoolSetting("Weapon Only", "Only trigger while holding a sword or axe.", false));
    private final BoolSetting players = add(new BoolSetting("Players Only", "Ignore mobs.", true));

    private long lockedAt;
    private class_1297 locked;

    public TriggerBot() {
        super("Trigger Bot", "Attacks the moment the crosshair settles on a valid target.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        class_746 player = MC.field_1724;
        if (player == null || MC.field_1755 != null || MC.field_1761 == null) {
            locked = null;
            return;
        }

        class_1297 hovered = null;
        if (MC.field_1765 instanceof class_3966 hit && hit.method_17782() instanceof class_1309 living
                && living != player && living.method_5805()) {
            if (!players.value() || living.method_5864() == net.minecraft.class_1299.field_6097) {
                if (player.method_5858(living) <= range.value() * range.value()) {
                    hovered = living;
                }
            }
        }

        if (hovered == null || !validWeapon()) {
            locked = null;
            lockedAt = 0L;
            return;
        }

        long now = System.currentTimeMillis();
        if (hovered != locked) {
            locked = hovered;
            double spread = ThreadLocalRandom.current().nextDouble(-16.0, 16.0);
            lockedAt = now + Math.max(0L, Math.round(delay.value() + spread));
            return;
        }
        if (now < lockedAt || player.method_7261(0.0f) < 0.92f) {
            return;
        }

        Input.attack(hovered);
        locked = null;
        lockedAt = 0L;
    }

    private boolean validWeapon() {
        if (!weapon.value() || MC.field_1724 == null) {
            return true;
        }
        String id = MC.field_1724.method_6047().method_7909().method_7876();
        return id.contains("sword") || id.contains("axe");
    }
}
