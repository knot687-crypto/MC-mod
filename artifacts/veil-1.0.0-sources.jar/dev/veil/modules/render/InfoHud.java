package dev.veil.modules.render;

import dev.veil.core.BoolSetting;
import dev.veil.core.CombatStats;
import dev.veil.gui.Render2D;
import dev.veil.gui.Theme;
import net.minecraft.class_332;
import net.minecraft.class_640;

public final class InfoHud extends HudModule {
    private final BoolSetting showCps = add(new BoolSetting("CPS", "Clicks per second.", true));
    private final BoolSetting showFps = add(new BoolSetting("FPS", "Frames per second.", true));
    private final BoolSetting showPing = add(new BoolSetting("Ping", "Current server latency.", true));

    public InfoHud() {
        super("Info", "Slim telemetry chips in the lower corner.");
    }

    @Override
    public void render(class_332 ctx, float delta) {
        int y = MC.method_22683().method_4502() - 20;
        int x = 8;
        if (showCps.value()) {
            x += chip(ctx, x, y, "cps", String.valueOf(CombatStats.cps()));
        }
        if (showFps.value()) {
            x += chip(ctx, x, y, "fps", String.valueOf(MC.method_47599()));
        }
        if (showPing.value()) {
            chip(ctx, x, y, "ping", String.valueOf(ping()));
        }
    }

    private int chip(class_332 ctx, int x, int y, String label, String value) {
        int width = Render2D.width(MC.field_1772, label) + Render2D.width(MC.field_1772, value) + 20;
        Render2D.rounded(ctx, x, y, width, 16, 4, 0xC70A0A10);
        Render2D.rounded(ctx, x, y, width, 16, 4, Theme.alpha(0xFFFFFF, 0.02f));
        Render2D.text(ctx, MC.field_1772, label, x + 7, y + 4, Theme.accent());
        Render2D.text(ctx, MC.field_1772, value, x + width - 7 - Render2D.width(MC.field_1772, value), y + 4, Theme.TEXT);
        return width + 5;
    }

    private int ping() {
        if (MC.field_1724 == null || MC.method_1562() == null) {
            return 0;
        }
        class_640 entry = MC.method_1562().method_2871(MC.field_1724.method_5667());
        return entry == null ? 0 : entry.method_2959();
    }
}
