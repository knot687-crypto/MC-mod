package dev.veil.modules.render;

import dev.veil.core.Category;
import dev.veil.core.Module;
import net.minecraft.class_310;
import net.minecraft.class_332;

public abstract class HudModule extends Module {
    protected static final class_310 MC = class_310.method_1551();

    protected HudModule(String name, String description) {
        super(name, description, Category.RENDER);
    }

    public abstract void render(class_332 ctx, float delta);
}
