package dev.veil.modules.render;

import dev.veil.core.Rotation;
import dev.veil.core.TargetManager;
import dev.veil.gui.Render2D;
import dev.veil.gui.Theme;
import net.minecraft.class_1309;
import net.minecraft.class_332;
import net.minecraft.class_640;

public final class TargetHud extends HudModule {
    private class_1309 last;
    private float health;
    private float healthMax = 20.0f;
    private float alpha;

    public TargetHud() {
        super("Target HUD", "Floating readout for whoever is currently targeted.");
    }

    @Override
    public void render(class_332 ctx, float delta) {
        class_1309 target = TargetManager.current();
        if (target != null) {
            last = target;
            healthMax = Math.max(1.0f, target.method_6063());
            health = approach(health, target.method_6032(), delta * 9.0f);
            alpha = approach(alpha, 1.0f, delta * 10.0f);
        } else if (last != null) {
            alpha = approach(alpha, 0.0f, delta * 7.0f);
            health = approach(health, 0.0f, delta * 5.0f);
            if (alpha < 0.02f) {
                last = null;
                return;
            }
        } else {
            return;
        }

        class_1309 display = target != null ? target : last;
        String name = display.method_5477().getString();
        int width = 178;
        int height = 46;
        int x = (MC.method_22683().method_4486() - width) / 2;
        int y = MC.method_22683().method_4502() / 2 + 52;

        int backdrop = Theme.alpha(0xFF0A0A10, 0.85f * alpha);
        Render2D.rounded(ctx, x, y, width, height, 7, backdrop);
        Render2D.rounded(ctx, x, y, width, height, 7, Theme.alpha(0xFFFFFF, 0.03f * alpha));
        Render2D.rounded(ctx, x, y, 2, height, 1, Theme.alpha(Theme.accent(), alpha));

        Render2D.text(ctx, MC.field_1772, name, x + 12, y + 9, Theme.alpha(Theme.TEXT, alpha));

        String distance = String.format("%.1fm", MC.field_1724 == null ? 0.0 : MC.field_1724.method_5739(display));
        Render2D.text(ctx, MC.field_1772, distance, x + width - 12 - Render2D.width(MC.field_1772, distance), y + 9,
                Theme.alpha(Theme.TEXT_FAINT, alpha));

        String hpText = String.format("%.1f", Math.max(0.0f, health));
        Render2D.text(ctx, MC.field_1772, hpText, x + 12, y + 21, Theme.alpha(Theme.accent(), alpha));

        int barX = x + 12 + Render2D.width(MC.field_1772, hpText) + 6;
        int barW = width - (barX - x) - 12;
        Render2D.rounded(ctx, barX, y + 26, barW, 3, 1, Theme.alpha(0xFFFFFF, 0.10f * alpha));
        float fraction = Math.max(0.0f, Math.min(1.0f, health / healthMax));
        Render2D.rounded(ctx, barX, y + 26, Math.max(1, Math.round(barW * fraction)), 3, 1, Theme.alpha(Theme.accent(), 0.95f * alpha));

        if (display instanceof net.minecraft.class_1657 player) {
            String ping = pingOf(player) + "ms";
            Render2D.text(ctx, MC.field_1772, ping, x + 12, y + 33, Theme.alpha(Theme.TEXT_FAINT, alpha));
        }
        String angle = Math.round(Rotation.angleTo(MC.field_1724 == null ? display.method_73189() : MC.field_1724.method_33571(),
                display.method_5829().method_1005(), MC.field_1724 == null ? 0 : MC.field_1724.method_36454(),
                MC.field_1724 == null ? 0 : MC.field_1724.method_36455())) + "\u00B0";
        Render2D.text(ctx, MC.field_1772, angle, x + width - 12 - Render2D.width(MC.field_1772, angle), y + 33,
                Theme.alpha(Theme.TEXT_FAINT, alpha));
    }

    private int pingOf(net.minecraft.class_1657 player) {
        if (MC.method_1562() == null) {
            return 0;
        }
        class_640 entry = MC.method_1562().method_2871(player.method_5667());
        return entry == null ? 0 : entry.method_2959();
    }

    private static float approach(float value, float target, float delta) {
        return value + (target - value) * Math.min(1.0f, delta);
    }
}
